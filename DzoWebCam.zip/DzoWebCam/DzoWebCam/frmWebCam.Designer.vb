﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmWebCam
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmdno = New System.Windows.Forms.Button()
        Me.cmdok = New System.Windows.Forms.Button()
        Me.pbcaptureimage = New System.Windows.Forms.PictureBox()
        Me.btnCapture = New System.Windows.Forms.PictureBox()
        CType(Me.pbcaptureimage, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnCapture, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdno
        '
        Me.cmdno.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cmdno.Image = Global.DzoWebCam.My.Resources.Resources.Actions_edit_delete_icon
        Me.cmdno.Location = New System.Drawing.Point(340, 411)
        Me.cmdno.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdno.Name = "cmdno"
        Me.cmdno.Size = New System.Drawing.Size(43, 30)
        Me.cmdno.TabIndex = 3
        Me.cmdno.UseVisualStyleBackColor = True
        '
        'cmdok
        '
        Me.cmdok.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cmdok.Image = Global.DzoWebCam.My.Resources.Resources.Ok_icon__1_1
        Me.cmdok.Location = New System.Drawing.Point(289, 411)
        Me.cmdok.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdok.Name = "cmdok"
        Me.cmdok.Size = New System.Drawing.Size(43, 30)
        Me.cmdok.TabIndex = 2
        Me.cmdok.UseVisualStyleBackColor = True
        '
        'pbcaptureimage
        '
        Me.pbcaptureimage.Location = New System.Drawing.Point(-1, -1)
        Me.pbcaptureimage.Margin = New System.Windows.Forms.Padding(4)
        Me.pbcaptureimage.Name = "pbcaptureimage"
        Me.pbcaptureimage.Size = New System.Drawing.Size(649, 385)
        Me.pbcaptureimage.TabIndex = 0
        Me.pbcaptureimage.TabStop = False
        '
        'btnCapture
        '
        Me.btnCapture.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCapture.Image = Global.DzoWebCam.My.Resources.Resources.Image_Capture_icon
        Me.btnCapture.Location = New System.Drawing.Point(371, 391)
        Me.btnCapture.Name = "btnCapture"
        Me.btnCapture.Size = New System.Drawing.Size(86, 62)
        Me.btnCapture.TabIndex = 4
        Me.btnCapture.TabStop = False
        '
        'frmWebCam
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(647, 458)
        Me.Controls.Add(Me.btnCapture)
        Me.Controls.Add(Me.cmdno)
        Me.Controls.Add(Me.cmdok)
        Me.Controls.Add(Me.pbcaptureimage)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmWebCam"
        Me.Text = "DzoWebCam"
        CType(Me.pbcaptureimage, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnCapture, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pbcaptureimage As System.Windows.Forms.PictureBox
    Friend WithEvents cmdok As System.Windows.Forms.Button
    Friend WithEvents cmdno As System.Windows.Forms.Button
    Friend WithEvents btnCapture As PictureBox
End Class
