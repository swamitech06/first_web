﻿Imports AForge
Imports AForge.Video
Imports AForge.Video.DirectShow
Imports System.IO
Public Class frmWebCam
    Dim camera As VideoCaptureDevice
    Dim bmp As Bitmap
    Dim cap As String = "Capture"

    Private Sub frmWebCam_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Try
            camera.Stop()
        Catch ex As Exception
            Me.Dispose()
        End Try
    End Sub
    Private Sub frmWebCam_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmdno.Visible = False
        cmdok.Visible = False
        Dim videoCapDevFrm As VideoCaptureDeviceForm = New VideoCaptureDeviceForm()

        If videoCapDevFrm.ShowDialog() = DialogResult.OK Then
            camera = videoCapDevFrm.VideoDevice
            AddHandler camera.NewFrame, New NewFrameEventHandler(AddressOf dzoCapture)
            camera.Start()
        Else
            Me.Close()
        End If
    End Sub
    Private Sub dzoCapture(sender As Object, eventArgs As NewFrameEventArgs)
        bmp = DirectCast(eventArgs.Frame.Clone(), Bitmap)
        pbcaptureimage.Image = DirectCast(eventArgs.Frame.Clone(), Bitmap)
    End Sub
    Private Sub btnCapture_Click(sender As Object, e As EventArgs) Handles btnCapture.Click
        If cap = "Capture" Then
            cmdno.Visible = True
            cmdok.Visible = True
            btnCapture.Visible = False
            camera.Stop()
            cap = "Start"
        ElseIf cap = "Start" Then
            camera.Start()
            cmdno.Visible = False
            cmdok.Visible = False
            cap = "Capture"
        End If
    End Sub

    Private Sub cmdno_Click(sender As Object, e As EventArgs) Handles cmdno.Click
        camera.Start()
        cmdno.Visible = False
        cmdok.Visible = False
        btnCapture.Visible = True
        cap = "Capture"
    End Sub

    Private Sub cmdok_Click(sender As Object, e As EventArgs) Handles cmdok.Click
        Dim saveDlg As New SaveFileDialog
        saveDlg.InitialDirectory = My.Computer.FileSystem.SpecialDirectories.Desktop
        saveDlg.FileName = "VBNetCapture_" & Date.Now.ToString("MM/dd/yy")
        saveDlg.SupportMultiDottedExtensions = True
        saveDlg.AddExtension = True
        saveDlg.Filter = "PNG File|*.png"
        If saveDlg.ShowDialog() = DialogResult.OK Then
            Try
                pbcaptureimage.Image.Save(saveDlg.FileName, Imaging.ImageFormat.Png)
                camera.Start()
                cmdno.Visible = False
                cmdok.Visible = False
                btnCapture.Visible = True
                cap = "Capture"
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        Else
            camera.Start()
            cmdno.Visible = False
            cmdok.Visible = False
            btnCapture.Visible = True
            cap = "Capture"
        End If
    End Sub


End Class
