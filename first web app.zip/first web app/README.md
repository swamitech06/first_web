# DVA489 Assignments

We are going to use GitHub Classroom to hand in assignments. We will be using pull requests for the handing in and feedback. If you are unfamiliar with Git or GitHub please enroll in the [Git & GitHub Fundamentals](https://classroom.github.com/a/2793ueZ9) assignment. For everything to work smoothly please adhere the the workflow described below.

# DVA489 Workflow

- never work directly in the main branch
- always work in the feedback branch
- hand in by making a pull request from the feeback branch into the main branch
- assign @salladsfisk as the pull request reviewer 
- do not merge the pull request
- feedback will be given in the pull reqest as comments and using the pull request review system
- once feedback has been given the teacher will merge the pull request into your main branch
- if you were asked to implement changes do so in the feedback branch and hand in using a new pull request

# Use of this README.md

Use this file to document your assignment and link to your attack videos if applicable.
