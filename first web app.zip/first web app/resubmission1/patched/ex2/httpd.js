const http = require("http");
const fs = require("fs");
const url = require("url");
const path = require('path');
//set global variables.
const publicDirectory = __dirname + "/public/";
const templateDirectory = __dirname + "/templates/";
const host = "127.0.0.1";
const port = 8000;

const mimeLookup = {
  '.js': 'text/javascript',
  '.html': 'text/html',
  '.css': 'text/css',
  '.ico':'text/ico'
};

/**
 * Send not found response
 *
 * @param res response
 * @param path path
 */
 function sendErrorResponse(res, path) {
  fs.readFile(templateDirectory + '/404.html', (err, data) => {
    if (err) {
      res.statusCode = 500;
      res.end();
    } else {
      res.statusCode = 404;
      res.end(data.toString().replace('{{message}}', path));
    }
  });
}


//Read file from filepath and send to the client
function sendResponse(filePath, res, cb) {
  fs.readFile(filePath, (err, data) => {
    if (err) {
      cb(err);
    } else {
      res.statusCode = 200;
      res.end(data);
    }
  });
}
//create the http server
var server = http.createServer((req, res) => {
  //Parse the request url
  let reqUrl = url.parse(req.url, true);
  
  let urlpath = ""
  try {
    urlpath = decodeURIComponent(reqUrl.pathname); // Get pathName of the url
  } catch(err) {
      res.statusCode = 404;
      res.end();
      return;
  }
  //if path contains static file then serve it
  if (urlpath.includes(".")) {
    let fileExt = path.extname(urlpath);
    if( !mimeLookup[fileExt]) {
      
      sendResponse(__dirname + urlpath, res, (err) => {
        sendErrorResponse(res, urlpath);
      })
    }
    else {
      sendResponse(publicDirectory + urlpath, res, (err) => {
        sendErrorResponse(res, urlpath);
      });
    }
    
    return;
  }

  //if the path contains index.html, then send index.html
  if (
    fs.existsSync(publicDirectory + urlpath + "index.html") &&
    fs.lstatSync(publicDirectory + urlpath + "index.html").isFile()
  ) {
    sendResponse(publicDirectory + urlpath + "index.html", res, (err) => {
      sendErrorResponse(res, urlpath);
    });
  } 
  // else send directory list
  else {
    //read directory
    fs.readdir(publicDirectory + urlpath, (err, files) => {
      if (err) {
        sendErrorResponse(res, urlpath);

      }
      else {
        let dirContent = "";
        //loop files and save to dirContent with <li>
        if (files && files.length > 0) {
          files.forEach((file) => {
            dirContent += `<li><a href="${
              "http://" + host + ":" + port + urlpath + "/" + file
            }">${file}</a></li>`;
          });
        } else {
          dirContent = "<li>Directory is empty!</li>";
        }
        //read directory template and write to the directoryList variable
        fs.readFile(templateDirectory + "directory.html", (err, data) => {
          if (err) {
            res.statusCode(500);
            res.end();
          } else {
            res.writeHead(200, { "Content-type": "text/html" });
            res.end(data.toString().replace("{{directoryList}}", dirContent));
          }
        });
      }
      
    });
  }
});

server.listen(8000);
