// import required packages
const http = require('http');
var server = http.createServer((req, res) => {
  //Set Content Type to "text/html"
  res.setHeader('Content-Type', 'text/html');
  //Set Response Status Code to 200
  res.statusCode = 200;
  //Return String "Hello World"
  res.end("<h1>Hello World</h1>");
});
server.listen(8000);