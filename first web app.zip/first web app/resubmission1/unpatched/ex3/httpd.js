const http = require("http");
const fs = require("fs");
const url = require("url");
const path = require("path");

//set global variables.
const publicDirectory = __dirname + "/public/";
const mimeLookup = {
  '.js': 'text/javascript',
  '.html': 'text/html',
  '.css': 'text/css',
  '.ico':'text/ico'
};

//Read file from filepath and send to the client
function sendResponse(filePath, res, cb) {
  fs.readFile(filePath, (err, data) => {
    if (err) {
      cb(err);
    } else {
      res.statusCode = 200;
      res.end(data);
    }
  });
}
//create the http server
var server = http.createServer((req, res) => {
  //Parse the request url
  let reqUrl = url.parse(req.url, true);
  let urlpath = decodeURIComponent(reqUrl.pathname); // Get pathName of the url
  // console.log(urlpath)

  if ( urlpath === '/index.html') {
    
    //print method and url
    console.log(`The request method is ${req.method} and the url is ${req.url}`);
    //get request body
    let body = [];
    req.on('data', (chunk) => {
      body.push(chunk);
    }).on('end', () => {
      body = Buffer.concat(body).toString();

      //print body content
      console.log(body);
    });
  }
  
  //if path contains static file then serve it
  if (urlpath.includes(".")) {
    let fileExt = path.extname(urlpath);
    if( !mimeLookup[fileExt]) {
      sendResponse(__dirname + urlpath, res, (err) => {
        throw err;
      })
    }
    else {
      sendResponse(publicDirectory + urlpath, res, (err) => {
        throw err;
      });
    }
    
    return;
    
  }
  if (urlpath === '/') {
  
    sendResponse(publicDirectory + '/index.html', res, (err) => {
      throw err
    });
  }

  
  
  

  
});

server.listen(8000);
