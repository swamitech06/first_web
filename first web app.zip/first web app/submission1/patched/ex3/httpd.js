const http = require("http");
const fs = require("fs");
const url = require("url");
const path = require("path");
//set global variables.
const publicDirectory = __dirname + "/public/";

const mimeLookup = {
  '.js': 'text/javascript',
  '.html': 'text/html',
  '.css': 'text/css',
  '.ico':'text/ico'
};

//Read file from filepath and send to the client
function sendResponse(filePath, res, cb) {
  fs.readFile(filePath, (err, data) => {
    if (err) {
      cb(err);
    } else {
      res.statusCode = 200;
      res.end(data);
    }
  });
}
/**
 * Send not found response
 *
 * @param res response
 * @param path path
 */
 function sendErrorResponse(res, path) {
  fs.readFile(templateDirectory + '/404.html', (err, data) => {
    if (err) {
      res.statusCode = 500;
      res.end();
    } else {
      res.statusCode = 404;
      res.end(data.toString().replace('{{message}}', path));
    }
  });
}

//create the http server
var server = http.createServer((req, res) => {
  //Parse the request url
  let reqUrl = url.parse(req.url, true);
  let urlpath = ""
  try {
    urlpath = decodeURIComponent(reqUrl.pathname); // Get pathName of the url
  } catch(err) {
      res.statusCode = 400;
      res.end();
      return;
  }
  if ( urlpath === '/index.html') {
    
    //print method and url
    console.log(`The request method is ${req.method} and the url is ${req.url}`);
    //get request body
    let body = [];
    req.on('data', (chunk) => {
      body.push(chunk);
    }).on('end', () => {
      body = Buffer.concat(body).toString();

    });
  }

  //if path contains static file then serve it
  if (urlpath.includes(".")) {
    let fileExt = path.extname(urlpath);
    if( !mimeLookup[fileExt]) {
      
      sendResponse(__dirname + urlpath, res, (err) => {
        sendErrorResponse(res, urlpath);
      })
    }
    else {
      sendResponse(publicDirectory + urlpath, res, (err) => {
        sendErrorResponse(res, urlpath);
      });
    }
    
    return;
    
  }
  if (urlpath === '/') {
    sendResponse(publicDirectory + '/index.html', res, (err) => {
      sendErrorResponse(res, urlpath);
    });
  }

  
  
  

  
});

server.listen(8000);
